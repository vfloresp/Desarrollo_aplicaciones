﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Odbc;

public partial class busquedaHist : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (CheckBoxList1.Items.Count == 0)
        {
            CheckBoxList1.Items.Add(new ListItem("Actual", "1"));
            CheckBoxList1.Items.Add(new ListItem("Pasada", "2"));
           // CheckBoxList1.Items.Add(new ListItem("Retardo", "3"));    YA NO HAY RETARDADO
        }

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("index.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("busquedaAdmin.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            String clave = TextBox1.Text;

            if (clave == "")
            {
                Label1.Text = "Escriba una clave";
            }
            else
            {
                Label1.Text = "";
                String query = "select cUs, fechaIn, fechaFin, cLibro, tipoRenta.nombre from renta, us_li_ren, tipoRenta where us_li_ren.cRenta = renta.cRenta and renta.cTipoRen = tipoRenta.cTipoRen " +
                                    " and cUs=? ";
                OdbcConnection con = new ConexionDB().con;
                con.Open();


                String extraQuery = "and tipoRenta.ctipoRen = ";
                
                if (CheckBoxList1.Items[0].Selected == true && CheckBoxList1.Items[1].Selected == false )
                {
                    query = query + extraQuery + 1;
                }
                if (CheckBoxList1.Items[1].Selected == true && CheckBoxList1.Items[0].Selected == false )
                {
                    query = query + extraQuery + 2;
                }
               

                    
                
                
                if (CheckBoxList1.Items[0].Selected == true && CheckBoxList1.Items[1].Selected == true)
                {
                    query = query + extraQuery + 1 + " union" +
                     "(select cUs, fechaIn, fechaFin, cLibro, tipoRenta.nombre from renta, us_li_ren, tipoRenta where us_li_ren.cRenta = renta.cRenta and renta.cTipoRen = tipoRenta.cTipoRen " +
                                    " and cUs=? and tipoRenta.ctipoRen = 2)";
                }

                

                
                OdbcCommand comando = new OdbcCommand(query, con);
                comando.Parameters.Add("cUs", OdbcType.VarChar).Value = clave;
                comando.Parameters.Add("cUs", OdbcType.VarChar).Value = clave;

                OdbcDataReader lector = comando.ExecuteReader();

                GridView1.DataSource = lector;
                GridView1.DataBind();  
                
            }

            
            

        }
        catch (Exception ex)
        {
            Response.Write("ERROR" + ex.ToString());
        }
    }
}
