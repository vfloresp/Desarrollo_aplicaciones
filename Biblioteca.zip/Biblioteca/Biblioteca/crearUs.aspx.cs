﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Odbc;

public partial class crearUs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {

            if (RadioButtonList1.Items.Count == 0)
            {

                OdbcConnection con = new ConexionDB().con;
                //siempre hay que ABRIR la CONEXION!!
                con.Open();
                /////////
                String query = "select nombre from rol";
                OdbcCommand comando = new OdbcCommand(query, con);

                //porque necesito la tabla completa
                OdbcDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    RadioButtonList1.Items.Add(new ListItem(lector.GetString(0))); //agregué las claves
                }
            }
        }
        catch (Exception ex)
        {

            Response.Write(ex.ToString());
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "" || TextBox2.Text == "" || TextBox3.Text == "" || RadioButtonList1.SelectedItem == null)
        {
            Label1.Text = "Llene todos los parámetros";
        }
        else
        {
            try
            {
                OdbcConnection con = new ConexionDB().con;
                con.Open();
                Label1.Text = "";
                Random rn = new Random();


                int cUs;
                int existe;
                do
                {
                    cUs = rn.Next(900000);
                    //checar si la llave primaria existe
                    String query2 = "select COUNT (cUs) from usuario where cUs=" + cUs;
                    OdbcCommand comando2 = new OdbcCommand(query2, con);
                    existe = (Int32)comando2.ExecuteScalar();
                } while (existe != 0);

                String nombre = TextBox1.Text;
                String correo = TextBox2.Text;
                String password = TextBox3.Text;

                int existe2;
                String query3 = "select COUNT (correo) from usuario where correo='" + correo + "'";
                OdbcCommand comando3 = new OdbcCommand(query3, con);
                OdbcDataReader lectorCor = comando3.ExecuteReader();
                lectorCor.Read();
                existe2 = lectorCor.GetInt32(0);

                if (existe2 == 1)
                {
                    Label1.Text = "Ya existe un usuario con ese correo";
                }
                else
                {
                    
                    String queryRol = "select cRol from rol where nombre = '" + RadioButtonList1.SelectedItem.Text + "'";
                    OdbcCommand comandoRol = new OdbcCommand(queryRol, con);
                    OdbcDataReader lectorRol = comandoRol.ExecuteReader();
                    lectorRol.Read();
                    int cRol = lectorRol.GetInt32(0);


                    String newUs = "insert into usuario values (?, ?, ?, ?, ?)";

                    OdbcCommand comando = new OdbcCommand(newUs, con);
                    comando.Parameters.Add("cUs", OdbcType.Int).Value = cUs;
                    comando.Parameters.Add("nombre", OdbcType.VarChar).Value = nombre;
                    comando.Parameters.Add("correo", OdbcType.VarChar).Value = correo;
                    comando.Parameters.Add("password", OdbcType.VarChar).Value = password;
                    comando.Parameters.Add("cRol", OdbcType.Int).Value = cRol;//selesctlkdgkjl
                    OdbcDataReader lector2 = comando.ExecuteReader();
                    lector2.Read();

                    Label1.Text = "Creado";
                }
                
            }


            catch (Exception ex)
            {

                Response.Write("ERROR " + ex.ToString());
            }

        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Administrador.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("index.aspx");
    }
}