﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Odbc;

public partial class busquedaAdmin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (CheckBoxList1.Items.Count == 0)
        {
            CheckBoxList1.Items.Add(new ListItem("cUs", "1"));
            CheckBoxList1.Items.Add(new ListItem("Nombre","2"));
            CheckBoxList1.Items.Add(new ListItem("Correo","3"));
            CheckBoxList1.Items.Add(new ListItem("cRol","4"));
            //CheckBoxList1.Items.Add(new ListItem("Historial", "5")); aquí no va esto
        }
        if (RadioButtonList1.Items.Count == 0)
        {
            RadioButtonList1.Items.Add(new ListItem("Administrador", "1"));
            RadioButtonList1.Items.Add(new ListItem("Usuario", "2"));
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Administrador.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("index.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            String query = "select ";
            String campos = "";

            for (int i = 0; i < CheckBoxList1.Items.Count - 1; i++)
            {
                if (CheckBoxList1.Items[i].Selected == true)
                {
                    campos = campos + CheckBoxList1.Items[i].Text.ToLower() + ",";
                }
            }
            if (campos == "")
            {
                campos = campos + "*";
            }
            else
            {
                campos = campos.Substring(0, campos.Length - 1);
            }

            String from = " from usuario where ";
            String where = "1=1";

            if (TextBox2.Text != "")
            {
                where = where + " and nombre = ?";
            }
            if (TextBox3.Text != "")
            {
                where = where + " and correo = ?";
            }
            if (TextBox4.Text != "")
            {
                where = where + " and cUs = ?";
            }

            if (RadioButtonList1.SelectedItem == null)
            {
                where = where + "";
            }
            else if (RadioButtonList1.SelectedItem.Text.Equals("Administrador"))
            {
                where = where + " and cRol = 1";
            }
            else if (RadioButtonList1.SelectedItem.Text.Equals("Usuario"))
            {
                where = where + " and cRol = 2";
            }



            query = query + campos + from + where;
            //Response.Write(query);

            OdbcConnection con = new ConexionDB().con;
            con.Open();
            OdbcCommand comando = new OdbcCommand(query, con);

            if (TextBox2.Text != "")
            {
                comando.Parameters.Add("nombre", OdbcType.VarChar).Value = TextBox2.Text;
            }
            if (TextBox3.Text != "")
            {
                comando.Parameters.Add("correo", OdbcType.VarChar).Value = TextBox3.Text;
            }
            if (TextBox4.Text != "")
            {
                comando.Parameters.Add("cUs", OdbcType.Int).Value = TextBox4.Text;
            }

            OdbcDataReader lector = comando.ExecuteReader();

            GridView1.DataSource = lector;
            GridView1.DataBind();     

        }
        catch (Exception)
        {
            Response.Write("DATOS INVALID0S ");
        }

       
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("busquedaHist.aspx");
    }
}