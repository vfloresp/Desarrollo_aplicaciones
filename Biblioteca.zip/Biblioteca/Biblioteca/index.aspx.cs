﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Odbc;


public partial class index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "" || TextBox2.Text == "")
        {
            Label1.Text = "Llene todos los campos";
        }
        else
        {
            try
            {
                OdbcConnection con = new ConexionDB().con;
                con.Open();

                String correo = TextBox1.Text;
                String password = TextBox2.Text;
                String query = "select cUs from usuario where correo=? and password=?";
                OdbcCommand comando = new OdbcCommand(query, con);
                //parámetros del query
                comando.Parameters.Add("correo", OdbcType.VarChar).Value = correo;
                comando.Parameters.Add("password", OdbcType.VarChar).Value = password;

                OdbcDataReader lector = comando.ExecuteReader();

                
                //Session["sesUs"] = lector.GetInt32(0);
               
                if (lector.HasRows == true)
                {
                    //el usuario se sabe su correo y su passwd
                     lector.Read();
                    //acepta la clave unica del usuario 
                    Session.Add("cUs", lector.GetInt32(0));
                    
                    //Response.Write(lector.GetInt32(0));
                    int cUs = lector.GetInt32(0);

                    Session["Clave"] = cUs;

                    OdbcConnection con2 = new ConexionDB().con;
                    con2.Open();

                    String query2 = "select cRol from usuario where cUs = ?";
                    OdbcCommand comando2 = new OdbcCommand(query2, con2);
                    comando2.Parameters.Add("cUs", OdbcType.Int).Value = cUs;
                    OdbcDataReader lector2 = comando2.ExecuteReader();
                    lector2.Read();

                    int cRol = lector2.GetInt32(0);

                    /*if (Session.ToString() != null)
                    {
                        Response.Write(Session.GetEnumerator());
                    }*/

                    if (cRol == 1)
                    {
                        Response.Redirect("administrador.aspx");
                    }
                    else
                    {
                        Response.Redirect("usuario.aspx");
                    }

                }
                else
                {
                    //el usuario puso tonterias
                    Label1.Text = "Datos incorrectos";
                    Session.Clear();
                    Session.Abandon();

                }
            
            }
            catch (Exception ex)
            {
                Response.Write("ERROR " + ex.ToString());
            }
        }
    }
}