﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Odbc;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try{

            if (DropDownList2.Items.Count == 0 )
            {

                OdbcConnection con = new ConexionDB().con;
                //siempre hay que ABRIR la CONEXION!!
                con.Open();
            
                String query = "select nombre from area";
                OdbcCommand comando = new OdbcCommand(query, con);

                //porque necesito la tabla completa
                OdbcDataReader lector = comando.ExecuteReader();
                while (lector.Read())
                {
                    DropDownList2.Items.Add(new ListItem(lector.GetString(0))); //agregué las claves
                }
            }
        }
        catch (Exception ex)        
        {

            Response.Write(ex.ToString());
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("index.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("administrador.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            OdbcConnection con = new ConexionDB().con;
            //siempre hay que ABRIR la CONEXION!!
            con.Open();
            //cambie de SelectedItem.toString a SelectedValue
            String NomArea = DropDownList2.SelectedValue;
            String queryAr = "select cArea from area where nombre = ?";
            OdbcCommand comandoAr = new OdbcCommand(queryAr, con);
            comandoAr.Parameters.Add("nombre", OdbcType.VarChar).Value = NomArea;
            OdbcDataReader lectorAr = comandoAr.ExecuteReader();
            lectorAr.Read();
            int cArea = lectorAr.GetInt32(0);
            Label1.Text = "";////

            if (TextBox1.Text !="" && TextBox2.Text != "")
            {
                Label1.Text = "Escribe un solo parámetro";
            }
            else
            {
                

                if (TextBox1.Text != "")
                {
                    String nombreL = TextBox1.Text;

                    if (DropDownList2.SelectedIndex == 0)
                    {
                        String queryNom = "update libro set cArea = ? , dias_renta = 10 where libro.nombre = ?";
                        OdbcCommand comandoNom = new OdbcCommand(queryNom, con);
                        comandoNom.Parameters.Add("cArea", OdbcType.Int).Value = cArea;
                        comandoNom.Parameters.Add("nombre", OdbcType.VarChar).Value = nombreL;
                        OdbcDataReader lector2 = comandoNom.ExecuteReader();
                        lector2.Read();
                    }
                    else
                    {
                        String queryNom = "update libro set cArea = ? , dias_renta = 0 where libro.nombre = ?";
                        OdbcCommand comandoNom = new OdbcCommand(queryNom, con);
                        comandoNom.Parameters.Add("cArea", OdbcType.Int).Value = cArea;
                        comandoNom.Parameters.Add("nombre", OdbcType.VarChar).Value = nombreL;
                        OdbcDataReader lector2 = comandoNom.ExecuteReader();
                        lector2.Read();
                    }
                    

                }
                if (TextBox2.Text != "")
                {
                    if (DropDownList2.SelectedIndex == 0)
                    {
                        int cLibro = Int32.Parse(TextBox2.Text);
                        String queryC = "update libro set cArea = ? , dias_renta = 10 where cLibro = ?";  //update los días a 10 para que después nos deje rentarlos
                        OdbcCommand comandoC = new OdbcCommand(queryC, con);
                        comandoC.Parameters.Add("cArea", OdbcType.Int).Value = cArea;
                        comandoC.Parameters.Add("cLibro", OdbcType.Int).Value = cLibro;
                        OdbcDataReader lector3 = comandoC.ExecuteReader();
                        lector3.Read();
                    }
                    else
                    {
                        int cLibro = Int32.Parse(TextBox2.Text);
                        String queryC = "update libro set cArea = ? , dias_renta = 0 where cLibro = ?";  //update los días a 10 para que después nos deje rentarlos
                        OdbcCommand comandoC = new OdbcCommand(queryC, con);
                        comandoC.Parameters.Add("cArea", OdbcType.Int).Value = cArea;
                        comandoC.Parameters.Add("cLibro", OdbcType.Int).Value = cLibro;
                        OdbcDataReader lector3 = comandoC.ExecuteReader();
                        lector3.Read();
                    }
                    



                }
                Label1.Text = "Cambio exitoso";
            }

           
            

        }
        catch (Exception ex)
        {

            Response.Write("El dato escrito está incorrecto " + ex.ToString());
        }
    }
}