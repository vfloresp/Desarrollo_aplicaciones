﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FunProc : Form
    {
        public FunProc()
        {
            InitializeComponent();

            comboBox1.ValueMember = "nombre";
            comboBox1.DataSource = BDManager.getTable("select nombre from cadena");

            fillSucursales(comboBox1.SelectedValue.ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BDManager.Parameter[] p = { BDManager.Parameter.create("cad", comboBox1.SelectedValue.ToString()),
                                          BDManager.Parameter.create("suc", comboBox2.SelectedValue.ToString()),
                                      };

            textBox1.Text = BDManager.function("cantprod", p);
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            fillSucursales(comboBox1.SelectedValue.ToString());
        }

        private void fillSucursales(string name)
        {
            comboBox2.ValueMember = "nombre";
            comboBox2.DataSource = BDManager.getTable("select sucursal.nombre from sucursal, cadena where cadena.nombre = '" + name + "' and " +
                "cadena.rfc = sucursal.rfc");
        }
    }
}
