﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Configuration;

namespace WindowsFormsApplication1
{
    public partial class FunProc : Form
    {
        public FunProc()
        {
            InitializeComponent();

            comboBox1.ValueMember = "nombre";
            comboBox1.DataSource = DBManager.getTable("select nombre from cadena");

            fillSucursales(comboBox1.SelectedValue.ToString(), comboBox2);

            comboBox3.ValueMember = "nombre";
            comboBox3.DataSource = DBManager.getTable("select nombre from producto");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DBManager.Parameter[] p = { DBManager.Parameter.create("cad", comboBox1.SelectedValue.ToString()),
                                          DBManager.Parameter.create("suc", comboBox2.SelectedValue.ToString()),
                                      };

            textBox1.Text = DBManager.function("cantprod", p);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DBManager.Parameter[] p = {   DBManager.Parameter.create("product", comboBox3.SelectedValue.ToString()),
                                          DBManager.Parameter.create("monto", textBox2.Text),
                                          DBManager.Parameter.create("cantidad", DBManager.Parameter.ReturnType.Number),
                                          DBManager.Parameter.create("nombre")

                                      };

            var a = DBManager.procedure("cadenasBaratas", p);
            textBox1.Text = "Cantidad de cadenas: " + a[0].ToString() + ", nombre de una: " + a[1].ToString();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            fillSucursales(comboBox1.SelectedValue.ToString(), comboBox2);
        }

        private void fillSucursales(string name, ComboBox box)
        {
            box.ValueMember = "nombre";
            box.DataSource = DBManager.getTable("select sucursal.nombre from sucursal, cadena where cadena.nombre = '" + name + "' and " +
                "cadena.rfc = sucursal.rfc");
        }
    }
}
