﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Cliente : Form
    {
        public Cliente()
        {
            InitializeComponent();

            comboBox1.ValueMember = "nombre";
            comboBox1.DataSource = DBManager.getTable("select nombre from Cliente");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string select = "select f.fecha, p.nombre, f.monto, count(pa.cpago), sum(pa.monto), f.saldo " +
                "from factura f, producto p, pago pa, disponibilidad d, prodfac pr, cliente c " +
                "where f.fecha between '" + dateTimePicker1.Value.ToShortDateString() + "' and current_date and f.cfac = pa.cfac and " +
                "f.cfac = pr.cfac and pr.cprod = d.cprod and d.cprod = p.cprod and f.cclien = c.cclien and " +
                "c.nombre = '" + comboBox1.SelectedValue.ToString() + "' group by f.fecha, f.cfac, p.nombre, f.monto, f.saldo";

            dataGridView1.DataSource = DBManager.getTable(select);
        }
    }
}
