﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Consultas : Form
    {
        public Consultas()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "Nombre de clientes cuyo saldo global es menor al 10% del monto de los artículos que compraron.";

            dataGridView1.DataSource = DBManager.getTable("Select nombre from cliente c, factura f where c.Cclien= f.cclien"+
                                                             " group by nombre"+
                                                             " having sum(f.saldo)< sum(f.monto)*0.1");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text = "Clientes que no han hecho compras este mes.";

            dataGridView1.DataSource = DBManager.getTable("select cliente.nombre, cadena.nombre from cliente, cadena, cadclien, factura where"+
                                                            " cliente.cclien = factura.cclien and factura.fecha between '01-03-2017' and '31-03-2017' and"+
                                                            " cliente.cclien = cadclien.cclien and cadclien.rfc = cadena.rfc"+
                                                            " group by cliente.nombre, cadena.nombre");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Text = "Sucursales y ventas realizadas el mes pasado menores a $50,000.";

            dataGridView1.DataSource = DBManager.getTable("Select c.nombre, s.nombre, sum(f.monto) from sucursal s, cadena c, factura f, disponibilidad d, prodfac pr"
                                                            +" where  c.rfc = s.rfc and s.csuc = d.csuc and d.csuc=pr.csuc  and pr.Cfac = f.Cfac" 
                                                           +" and  f.fecha between '13-02-2017' and '13-03-2017'"
                                                            +" group by s.nombre, c.nombre"
                                                            +" having sum(f.monto)<50000");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label1.Text = "Cadena con más sucursales.";

            dataGridView1.DataSource = DBManager.getTable("select cadena.nombre, cadena.domicilio from cadena, sucursal where"+
                                        " sucursal.rfc = cadena.rfc and cadena.nombre = 'walmart'");
        }
    }
}
