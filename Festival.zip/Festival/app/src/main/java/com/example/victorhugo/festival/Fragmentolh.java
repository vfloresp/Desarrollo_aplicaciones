package com.example.victorhugo.festival;


import android.app.ListFragment;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;


public class Fragmentolh extends ListFragment {

    InterfazBD iBD;
    Cursor res;
    SimpleCursorAdapter sca;
    ConexionBD con;


    public Fragmentolh() {
        // Required empty public constructor
    }

    @SuppressWarnings("deprecation")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v=super.onCreateView(inflater, container, savedInstanceState);
        String []arregloColumnas={"fecha","artista", "escenario"};
        int []columnasGUI={R.id.texto1,R.id.texto2, R.id.texto3};
        iBD=new InterfazBD(this.getActivity());
        res=iBD.traerTodosDatos();// ESTE ES EL PROBLEMA
        if(res == null){
            return v;
        }
        //Pasarle el cursor a la actividad
        //startManagingCursor(res);
        //Crear el adaptador para mostrar los datos
        sca=new SimpleCursorAdapter(
                this.getActivity(), //Actividad papa de todos
                R.layout.formato_renglon, //Formato que se repite en la lista
                res, //Cursor que tiene los datos de la consulta
                arregloColumnas, //Nombres de las columnas de la bd
                columnasGUI, //Elementos destino en el layout del renglon
                0); //Este cero no hay que pelarlo
        //Pegar el adaptador a la lista
        this.setListAdapter(sca);


        return v;
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        // TODO Auto-generated method stub
        //super.onListItemClick(l, v, position, id);
        if(iBD==null){
            iBD=new InterfazBD(this.getActivity());
        }

        String[] s=iBD.traerDato(id);
        int res = iBD.insertaDatoI(s[0],s[1],s[2]);
        Toast t;
        if(res==1){
            t=Toast.makeText(getActivity(),"Ya tienes un evento a esa hora", Toast.LENGTH_SHORT);

        }
        else{
            t=Toast.makeText(getActivity(),"Evento agregado", Toast.LENGTH_SHORT);
        }
        t.show();
    }








}
