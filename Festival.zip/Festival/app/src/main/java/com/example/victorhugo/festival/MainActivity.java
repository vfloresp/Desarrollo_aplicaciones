package com.example.victorhugo.festival;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.app.FragmentManager;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.app.FragmentTransaction;
import android.widget.TextView;


public class MainActivity extends Activity {
    Button b1,b2,b3;
    TextView bo;
    Fragmentomen fragmento;
   FragmentManager fm;
    FragmentTransaction ft,ft2,ft3,ft4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        fragmento = new Fragmentomen();
        fm = this.getFragmentManager();

        ft = fm.beginTransaction();
        ft.add(R.id.lay,fragmento);
        ft.commit();
    }
}
