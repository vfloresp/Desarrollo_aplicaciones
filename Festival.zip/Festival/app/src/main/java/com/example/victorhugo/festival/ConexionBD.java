package com.example.victorhugo.festival;
import android.content.ContentValues;
import android. content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;


public class ConexionBD extends SQLiteOpenHelper {

    String cadenaCreate = "create table if not exists tablahorario(_id integer primary key autoincrement," +
            " artista text not null, fecha time , escenario text)";
    String cadenaCreate2 = "create table if not exists tablahorario2(_id integer primary key autoincrement," +
            " artista text not null, fecha time , escenario text)";
    String cadenaCreate3 = "create table if not exists tablaitinerario(_id integer primary key autoincrement," +
            " artista text not null, fecha time , escenario text)";
    String cadenaCreate4 = "create table if not exists tablaitinerario2(_id integer primary key autoincrement," +
            " artista text not null, fecha time , escenario text)";

    public ConexionBD(Context context){
        super(context,"horario.db", null, 1);
    }

    public void onCreate(SQLiteDatabase db){
        db.execSQL(cadenaCreate);
        db.execSQL(cadenaCreate2);
        db.execSQL(cadenaCreate3);
        db.execSQL(cadenaCreate4);
    }



    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        String cadenaUptade = "drop table if exists tablahorario;";
        db.execSQL(cadenaCreate);
        onCreate(db);

    }
}

