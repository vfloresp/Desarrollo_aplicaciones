package com.example.victorhugo.festival;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragmentomen extends Fragment {
    Button b1,b2,b3;
    TextView bo;
    Fragmentom fragmento1;
    Fragmentob fragmento2;
    Fragmentoh fragmento3;
    Fragmentoi fragmento4;
    FragmentManager fm;
    FragmentTransaction ft,ft2,ft3,ft4;


    public Fragmentomen() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_fragmentomen, container, false);
        fm = this.getFragmentManager();
        b1 = (Button) v.findViewById(R.id.boton1);
        fragmento1 = new Fragmentom();
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ft = fm.beginTransaction();
                ft.replace(R.id.lay,fragmento1);
                ft.commit();
            }
        });
        bo = (TextView) v.findViewById(R.id.compra);
        fragmento2 = new Fragmentob();
        bo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ft2 = fm.beginTransaction();
                ft2.replace(R.id.lay, fragmento2);
                ft2.commit();
            }
        });

        b2 = (Button) v.findViewById(R.id.boton2);
        fragmento3 = new Fragmentoh();
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ft3 = fm.beginTransaction();
                ft3.replace(R.id.lay, fragmento3);
                ft3.commit();
            }
        });

        b3 = (Button) v.findViewById(R.id.boton3);
        fragmento4 = new Fragmentoi();
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ft4 = fm.beginTransaction();
                ft4.replace(R.id.lay, fragmento4);
                ft4.commit();
            }
        });
        return v;
    }

}
