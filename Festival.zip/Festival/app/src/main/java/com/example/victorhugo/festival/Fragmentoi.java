package com.example.victorhugo.festival;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragmentoi extends Fragment {
    Button borrar,dia1, dia2;
    FragmentManager fm;
    FragmentTransaction ft,ft1,ft2;
    Fragmentoli fragmentoli;
    Fragmentoli2 fragmentoli2;
    Fragmentomen fragmento1;



    public Fragmentoi() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_fragmentoi, container, false);

        fragmentoli = new Fragmentoli();
        fm = this.getFragmentManager();
        ft = fm.beginTransaction();
        ft.add(R.id.layout, fragmentoli);
        ft.commit();


        fragmento1 = new Fragmentomen();



        borrar = (Button) v.findViewById(R.id.buttonRegresar);
        borrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().getFragmentManager().beginTransaction().remove(Fragmentoi.this).commit();
                fm = getFragmentManager();
                ft = fm.beginTransaction();
                ft.add(R.id.lay, fragmento1);
                ft.commit();
            }
        });


        fragmentoli2 = new Fragmentoli2() ;
        dia2 = (Button) v.findViewById(R.id.dia4);
        dia2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fm = getFragmentManager();
                ft2 = fm.beginTransaction();
                ft2.replace(R.id.layout, fragmentoli2);
                ft2.commit();
            }
        });



        dia1 = (Button) v.findViewById(R.id.dia3);
        dia1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //getActivity().getFragmentManager().beginTransaction().remove(Fragmentoh.this).commit();
                fm = getFragmentManager();
                ft1 = fm.beginTransaction();
                ft1.replace(R.id.layout, fragmentoli);
                ft1.commit();
            }
        });

        return v;
    }

}
