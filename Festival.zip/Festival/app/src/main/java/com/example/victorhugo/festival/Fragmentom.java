package com.example.victorhugo.festival;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragmentom extends Fragment {
    WebView wb;
    Button borrar;
    Fragmentomen fragmento;
    FragmentManager fm;
    FragmentTransaction ft;

    public Fragmentom() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v =inflater.inflate(R.layout.fragment_fragmentom, container, false);
        wb= (WebView) v.findViewById(R.id.web);
        wb.getSettings().setJavaScriptEnabled(true);
        wb.loadUrl("https://www.google.com.mx/maps/place/Provinciaal+Recreatiedomein+De+Schorre" +
                "/@51.088348,4.3798493,17z/data=!3m1!4b1!4m5!3m4!1s0x47c3ee3b6465f7bf:0x4c64aa6a2defbc53!" +
                "8m2!3d51.088348!4d4.382038");
        wb.setWebViewClient(new MiWebViewClient());
        fragmento = new Fragmentomen();


        borrar = (Button) v.findViewById(R.id.buttonBorrar);
        borrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().getFragmentManager().beginTransaction().remove(Fragmentom.this).commit();
                fm = getFragmentManager();
                ft = fm.beginTransaction();
                ft.add(R.id.lay,fragmento);
                ft.commit();
            }
        });

        return v;

    }

}

class MiWebViewClient extends WebViewClient{
    public boolean shouldOverrideUrlLOading(WebView view, String url){
        view.loadUrl(url);
        return true;
    }
}

