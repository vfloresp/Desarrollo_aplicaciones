package com.example.victorhugo.festival;
import android.content.ContentValues;
import android. content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;

public class InterfazBD {
    ConexionBD con;
    SQLiteDatabase db;


    public InterfazBD(Context context){
        con=new ConexionBD(context);
    }

    public void open() throws SQLiteException {
        db=con.getWritableDatabase();
    }

    public void close() throws SQLiteException {
        con.close();
    }

    public void borrarI(Long id){
        open();
        String clave = Long.toString(id);
        //String query= "delete from tablaitinerario where artista="+artista+"and fecha="+hora;
        String query= "delete from tablaitinerario where _id="+clave;
        Cursor c=db.rawQuery(query,null);
        c.moveToNext();
        close();

    }


    public void borrarI2(Long id){
        open();
        String clave = Long.toString(id);
        //String query= "delete from tablaitinerario where artista="+artista+"and fecha="+hora;
        String query= "delete from tablaitinerario2 where _id="+clave;
        Cursor c=db.rawQuery(query,null);
        c.moveToNext();
        close();

    }



    public int insertaDatoI(String artista, String hora, String escenario){
        ContentValues valores;
        open();

        String query="select tablaitinerario.fecha from tablaitinerario where tablaitinerario.fecha='"+hora+"'";
        Cursor c=db.rawQuery(query,null);
        c.moveToNext();

        if(c.getCount()==1){
            return 1;
        }
        valores=new ContentValues();
        valores.put("artista",artista);
        valores.put("fecha", hora);
        valores.put("escenario",escenario);
        db.insert("tablaitinerario", null, valores);
        return 2;


    }

    public int insertaDatoI2(String artista, String hora, String escenario){
        ContentValues valores;
        open();

        String query="select tablaitinerario2.fecha from tablaitinerario2 where tablaitinerario2.fecha='"+hora+"'";
        Cursor c=db.rawQuery(query,null);
        c.moveToNext();

        if(c.getCount()==1){
            return 1;
        }
        valores=new ContentValues();
        valores.put("artista",artista);
        valores.put("fecha", hora);
        valores.put("escenario",escenario);
        db.insert("tablaitinerario2", null, valores);
        return 2;


    }



    public void insertarDatosPrueba() {
        ContentValues valores;
        open();

        valores=new ContentValues();
        valores.put("artista","Afrojack");
        valores.put("fecha", "11:00");
        valores.put("escenario","Mainstage");
        db.insert("tablahorario", null, valores);
        valores=new ContentValues();
        valores.put("artista","Hardwell");
        valores.put("fecha", "11:00");
        valores.put("escenario","V Sessions");
        db.insert("tablahorario", null, valores);
        valores=new ContentValues();
        valores.put("artista","Steve Aoki");
        valores.put("fecha", "14:00");
        valores.put("escenario","Mainstage");
        db.insert("tablahorario", null, valores);
        valores=new ContentValues();
        valores.put("artista","Nervo");
        valores.put("fecha", "18:00");
        valores.put("escenario","Super You&Me");
        db.insert("tablahorario", null, valores);
        valores=new ContentValues();
        valores.put("artista","David Guetta");
        valores.put("fecha", "09:00");
        valores.put("escenario","Super You&Me");
        db.insert("tablahorario", null, valores);

    }

    public void insertarDatosPrueba2() {
        ContentValues valores;
        open();

        valores=new ContentValues();
        valores.put("artista","Solomun");
        valores.put("fecha", "11:00");
        valores.put("escenario","Mainstage");
        db.insert("tablahorario2", null, valores);
        valores=new ContentValues();
        valores.put("artista","Dimitri Vegas");
        valores.put("fecha", "11:00");
        valores.put("escenario","Cafeina");
        db.insert("tablahorario2", null, valores);
        valores=new ContentValues();
        valores.put("artista","Armin Van Buren");
        valores.put("fecha", "14:00");
        valores.put("escenario","Cafeina");
        db.insert("tablahorario2", null, valores);
        valores=new ContentValues();
        valores.put("artista","Alesso");
        valores.put("fecha", "18:00");
        valores.put("escenario","Super You&Me");
        db.insert("tablahorario2", null, valores);
        valores=new ContentValues();
        valores.put("artista","Robin Schulz");
        valores.put("fecha", "09:00");
        valores.put("escenario","Mainstage");
        db.insert("tablahorario2", null, valores);

    }

    public String[] traerDato(Long clave){
        open();
        String claveString=Long.toString(clave);
        String query="select * from tablahorario where _id="+claveString+";";
        Cursor c=db.rawQuery(query,null);
        // es necesario ponerlo, si no no va a funcionar
        c.moveToNext();
        String[] res = new String[3];
        res[0]= c.getString(1);
        res[1]= c.getString(2);
        res[2]= c.getString(3);
        c.close();
        close();
        return res;
    }

    public String[] traerDato2(Long clave){
        open();
        String claveString=Long.toString(clave);
        String query="select * from tablahorario2 where _id="+claveString+";";
        Cursor c=db.rawQuery(query,null);
        // es necesario ponerlo, si no no va a funcionar
        c.moveToNext();
        String[] res = new String[3];
        res[0]= c.getString(1);
        res[1]= c.getString(2);
        res[2]= c.getString(3);
        c.close();
        close();
        return res;
    }


    public Cursor traerTodosDatos(){
        Cursor res=null;
        open();
        String query="select * from tablahorario order by tablahorario.fecha asc;";
        res=db.rawQuery(query,null);
        if(res.getCount()==0) {
            insertarDatosPrueba();
            res=db.rawQuery(query,null);
        }
        //en este caso no se cierra la base porque eso elimina el cursor
        return res;
    }



    public Cursor traerTodosDatos2(){
        Cursor res=null;
        open();
        String query="select * from tablahorario2 order by tablahorario2.fecha asc;";
        res=db.rawQuery(query,null);
        if(res.getCount()==0) {
            insertarDatosPrueba2();
            res=db.rawQuery(query,null);
        }
        //en este caso no se cierra la base porque eso elimina el cursor
        return res;
    }


    public Cursor traerTodosDatosI(){
        Cursor res=null;
        open();
        String query="select * from tablaitinerario order by tablaitinerario.fecha asc;";
        res=db.rawQuery(query,null);
        if(res.getCount()==0) {
            return null;
        }
       //en este caso no se cierra la base porque eso elimina el cursor
        return res;
    }


    public Cursor traerTodosDatosI2(){
        Cursor res=null;
        open();
        String query="select * from tablaitinerario2 order by tablaitinerario2.fecha asc;";
        res=db.rawQuery(query,null);
        if(res.getCount()==0) {
            return null;
        }
        //en este caso no se cierra la base porque eso elimina el cursor
        return res;
    }



}
