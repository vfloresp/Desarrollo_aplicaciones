package com.example.victorhugo.festival;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.database.Cursor;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.app.ListFragment;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 */
public class Fragmentoli2 extends ListFragment {
    InterfazBD  iBD2;
    Cursor res;
    SimpleCursorAdapter sca2;
    Fragmentoaux fragmentoaux;
    FragmentManager fm;
    FragmentTransaction  ft2;
    Fragmentoli fragmentoli;

    public Fragmentoli2() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v=super.onCreateView(inflater, container, savedInstanceState);

        String []arregloColumnas2={"fecha","artista", "escenario"};
        int []columnasGUI2={R.id.texto1,R.id.texto2, R.id.texto3};
        iBD2=new InterfazBD(this.getActivity());
        res=iBD2.traerTodosDatosI2();
        fragmentoaux = new Fragmentoaux();

        if(res == null){
            fm = getFragmentManager();
            ft2= fm.beginTransaction();
            ft2.replace(R.id.layout, fragmentoaux);
            ft2.commit();
        }
        //Pasarle el cursor a la actividad
        //startManagingCursor(res);
        //Crear el adaptador para mostrar los datos
        sca2=new SimpleCursorAdapter(
                this.getActivity(), //Actividad papa de todos
                R.layout.formato_renglon, //Formato que se repite en la lista
                res, //Cursor que tiene los datos de la consulta
                arregloColumnas2, //Nombres de las columnas de la bd
                columnasGUI2, //Elementos destino en el layout del renglon
                0); //Este cero no hay que pelarlo
        //Pegar el adaptador a la lista
        this.setListAdapter(sca2);

        return v;
    }



    public void onListItemClick(ListView l, View v, int position, long id) {
        // TODO Auto-generated method stub
        //super.onListItemClick(l, v, position, id);
        if(iBD2==null){
            iBD2=new InterfazBD(this.getActivity());
        }

        iBD2.borrarI2(id);
        Toast t=Toast.makeText(getActivity(),"Borrado", Toast.LENGTH_SHORT);
        t.show();

        String []arregloColumnas={"fecha","artista", "escenario"};
        int []columnasGUI={R.id.texto1,R.id.texto2, R.id.texto3};
        iBD2=new InterfazBD(this.getActivity());
        res=iBD2.traerTodosDatosI2();//
        fragmentoaux = new Fragmentoaux();
        if(res == null){
            fm = getFragmentManager();
            ft2 = fm.beginTransaction();
            ft2.replace(R.id.layout, fragmentoaux);
            ft2.commit();
        }
        //Pasarle el cursor a la actividad
        //startManagingCursor(res);
        //Crear el adaptador para mostrar los datos
        sca2=new SimpleCursorAdapter(
                this.getActivity(), //Actividad papa de todos
                R.layout.formato_renglon, //Formato que se repite en la lista
                res, //Cursor que tiene los datos de la consulta
                arregloColumnas, //Nombres de las columnas de la bd
                columnasGUI, //Elementos destino en el layout del renglon
                0); //Este cero no hay que pelarlo
        //Pegar el adaptador a la lista
        this.setListAdapter(sca2);


    }

}
