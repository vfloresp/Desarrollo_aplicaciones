package com.example.victorhugo.festival;


import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragmentob extends Fragment {
    WebView wb;
    Button borrar;
    FragmentManager fm;
    FragmentTransaction ft;
    Fragmentomen fragmento1;

    public Fragmentob() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v =inflater.inflate(R.layout.fragment_fragmentob, container, false);
        wb= (WebView) v.findViewById(R.id.web);
        wb.getSettings().setJavaScriptEnabled(true);
        wb.loadUrl("https://www.tomorrowland.com/en/festival/tickets");
        wb.setWebViewClient(new MiWebViewClient());


        fragmento1 = new Fragmentomen();


        borrar = (Button) v.findViewById(R.id.buttonBorrar);
        borrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getActivity().getFragmentManager().beginTransaction().remove(Fragmentob.this).commit();
                fm = getFragmentManager();
                ft = fm.beginTransaction();
                ft.add(R.id.lay, fragmento1);
                ft.commit();
            }
        });
        return v;
    }

}


