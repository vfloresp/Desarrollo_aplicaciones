﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Odbc;

public partial class alta_baja : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (DropDownList1.Items.Count == 0)
        {
            DropDownList1.Items.Add(new ListItem("Uso libre", "9045"));
            DropDownList1.Items.Add(new ListItem("Solo lectura", "9289"));
            DropDownList1.Items.Add(new ListItem("Restringido", "9123"));
        }
     
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            if (TextBox1.Text=="")
            {
                Label1.Text = "Escriba una clave";
            }
            else
            {
                OdbcConnection con = new ConexionDB().con;
                con.Open();


                Label1.Text = "";
                int cLibro = Int32.Parse(TextBox1.Text);

                String query2 = "delete us_li_ren where cLibro = " + cLibro;
                OdbcCommand comando2 = new OdbcCommand(query2, con);
                comando2.Parameters.Add("cLibro", OdbcType.Int).Value = cLibro;


                OdbcDataReader lector2 = comando2.ExecuteReader();
                lector2.Read();

                String query = "delete libro where cLibro =" + cLibro;
                OdbcCommand comando = new OdbcCommand(query, con);
                comando.Parameters.Add("cLibro", OdbcType.Int).Value = cLibro;


                OdbcDataReader lector = comando.ExecuteReader();
                lector.Read();

                Label1.Text = "Baja exitosa";
            }
           

        }
        catch (Exception ex)
        {
            Response.Write("La clave no existe" + ex.ToString());
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            OdbcConnection con = new ConexionDB().con;
            con.Open();

            if (TextBox2.Text == "" || TextBox3.Text == "" || TextBox4.Text == "" || TextBox5.Text == "" || DropDownList1.SelectedValue == null )
            {
                Label2.Text = "Faltan datos";
            }
            else
            {

                Label2.Text = "";
                String nombre = TextBox2.Text;
                String autor = TextBox3.Text;
                String editorial = TextBox4.Text;
                int area = Int32.Parse(DropDownList1.SelectedValue);


                int dias = Int32.Parse(TextBox5.Text);
               
                int cLib;
                int existe;
                Random rn = new Random();
                do
                {
                    cLib = rn.Next(900000);
                    //checar si la llave primaria existe
                    String query2 = "select COUNT (cLibro) from libro where cLibro=" + cLib;
                    OdbcCommand comando2 = new OdbcCommand(query2, con);
                    existe = (Int32)comando2.ExecuteScalar();
                } while (existe != 0);

                String query = "insert into libro values( ?, ? , ? , ? , ?, ? )" ;
                OdbcCommand comando = new OdbcCommand(query, con);
                comando.Parameters.Add("cLibro", OdbcType.Int).Value = cLib;
                comando.Parameters.Add("nombre", OdbcType.VarChar).Value = nombre;
                comando.Parameters.Add("autor", OdbcType.VarChar).Value = autor;
                comando.Parameters.Add("editorial", OdbcType.VarChar).Value = editorial;
                comando.Parameters.Add("dias_renta", OdbcType.Int).Value = dias;
                comando.Parameters.Add("cArea", OdbcType.Int).Value = area;

                OdbcDataReader lector26 = comando.ExecuteReader();
                lector26.Read();
                Label2.Text = "Alta exitosa";


            }


        }
        catch (Exception ex)
        {
            Response.Write("Error en los datos" + ex.ToString());
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedValue != "9045")
        {
            TextBox5.Text = "0";
        }
        else
        {
            TextBox5.Text = "";
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Redirect("administrador.aspx");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("index.aspx");
    }
}