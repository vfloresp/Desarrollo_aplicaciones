﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Odbc;

public partial class devolver : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        /*if (ListBox1.Items.Count == 0)
        {
            OdbcConnection con = new ConexionDB().con;
            con.Open();
            String query = "select  libro.nombre, libro.cLibro from libro, us_li_ren, usuario, renta, tipoRenta where us_li_ren.cUs = usuario.cUs and us_li_ren.cRenta = renta.cRenta and libro.cLibro = us_li_ren.cLibro and renta.cTipoRen = tipoRenta.cTipoRen and renta.cTipoRen=1 and  usuario.cUs = ?";
            int cUs = Int32.Parse(Session["Clave"].ToString());
            OdbcCommand comando = new OdbcCommand(query, con);
            comando.Parameters.Add("cUs", OdbcType.Int).Value = cUs;

            OdbcDataReader lector = comando.ExecuteReader();
            while (lector.Read())/////
	        {
                ListBox1.Items.Add(new ListItem(lector.GetString(0), lector.GetInt32(1).ToString()));
	        }
           
        */
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            //Response.Write(ListBox1.SelectedValue);
            if (ListBox1.SelectedValue == null)
            {
                Label1.Text = "Seleccione el libro que quiere devolver";
            }
            else
            {
                Label1.Text = "";
                OdbcConnection con = new ConexionDB().con;
                con.Open();

                //Response.Write(ListBox1.SelectedItem);

                int cUs = Int32.Parse(Session["Clave"].ToString());
                int cLibro = Int32.Parse(ListBox1.SelectedValue.ToString());

                String query = "select renta.cRenta from usuario, us_li_ren, renta, libro, tipoRenta where usuario.cUs = us_li_ren.cUs and tipoRenta.cTipoRen = renta.cTipoRen  and  us_li_ren.cLibro = libro.cLibro and us_li_ren.cRenta = renta.cRenta and tipoRenta.cTipoRen = 1 and usuario.cUs = ? and libro.cLibro = ?";
                
                OdbcCommand comando = new OdbcCommand(query, con);
                comando.Parameters.Add("cUs", OdbcType.Int).Value = cUs;
                comando.Parameters.Add("cLibro", OdbcType.Int).Value = cLibro;

                OdbcDataReader lector = comando.ExecuteReader();
                lector.Read();

                int cRenta = lector.GetInt32(0);
                

                query = "update renta set cTipoRen = 2 where  cRenta = ?";
                comando = new OdbcCommand(query, con);
                comando.Parameters.Add("cRenta", OdbcType.Int).Value = cRenta;
                lector = comando.ExecuteReader();
                lector.Read();

                //Label1.Text = "Devolución exitosa";

                Response.Redirect("devolver.aspx");
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error " + ex.ToString());
        }
    }
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ListBox1.SelectedValue != null)
        {
            Label2.Text =  ListBox1.SelectedValue.ToString();
        }
        else
        {
            Label2.Text = "";
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("usuario.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("index.aspx");
    }
}