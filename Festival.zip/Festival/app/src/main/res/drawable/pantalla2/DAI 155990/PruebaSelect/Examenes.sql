create table alumno
(Cu int primary Key,
correo varchar(40),
passwd varchar(40),
nomber varchar(40)) 

insert into alumno values (1,'jorge@hotmail.com','jorgito', 'Jorge')

insert into alumno values(2,'pepe@hotmail.com','pepito', 'Pepe')

insert into alumno values (3,'paty@hotmail.com','paty', 'Patricia')

insert into alumno values (4,'pedro@hotmail.com','pedrito', 'Pedro')

insert into alumno values (5,'julia@hotmail.com','july', 'Julia')

Select * from alumno
delete  from alumno