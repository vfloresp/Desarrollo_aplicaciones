﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Odbc;

/// <summary>
/// Descripción breve de ConexionDB
/// </summary>
public class ConexionDB
{
    public OdbcConnection con {get; set;}
	public ConexionDB()
	{
        try
        {
            //--Acceder al web.config y leer el connectionString
            //APRENDER  

            //objetos para poder acceder al web.config
            System.Configuration.Configuration rootWebConfig =
            System.Web.Configuration.WebConfigurationManager.OpenWebConfiguration("/Biblioteca");
            //declaro un objeto connectionString para leer el string de conexion del web.config
            System.Configuration.ConnectionStringSettings connString;
            //traigo el string de conexion del web.config al objeto connectionString
            connString = rootWebConfig.ConnectionStrings.ConnectionStrings["Biblioteca"];

            //--Acceder al web.cofig y leer el connectionString

            //crear la conexion con el connectionString que lei
            this.con = new OdbcConnection(connString.ToString());
        }
        catch (Exception ex)
        {
            Console.Write("Error: " + ex.ToString());
        }

	}
}