create table rol(
	cRol int primary key,
	nombre varchar (50))

create table usuario(
	cUs int primary key,
	nombre varchar (50),
	correo varchar(50),
	password varchar (50),
	cRol int references rol)

create table area(
	cArea int primary key,
	nombre varchar (50))

create table libro(
	cLibro int primary key,
	nombre varchar (50),
	autor varchar (50),
	editorial varchar (50),
	dias_renta int,
	cArea int references area)

create table tipoRenta(
	cTipoRen int primary key,
	nombre varchar (50))

create table renta(
	cRenta int primary key,
	fechaIn date,
	fechaFin date,
	cTipoRen int references tipoRenta) 

create table us_li_ren(
	cUs int references usuario,
	cLibro int references libro,
	cRenta int references renta, 
	primary key(cRenta, cLibro))


--drop table us_li_ren
