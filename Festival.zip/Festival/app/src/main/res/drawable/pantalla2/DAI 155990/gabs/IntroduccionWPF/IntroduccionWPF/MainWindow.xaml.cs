﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IntroduccionWPF
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void botonNombre_Click(object sender, RoutedEventArgs e)
        {
            labelResultado.Content = textBox_nombre.Text;
            listBoxNom.Items.Add(textBox_nombre.Text);
            //borrarlo del textbox por presentacion
            textBox_nombre.Text = "";
        }

        private void boton_orden_Click(object sender, RoutedEventArgs e)
        {
            String orden = "Su orden es :";
            if (check1.IsChecked == true)
            {
                orden = orden + " chocolate,";
            }
            if (check2.IsChecked == true)
            {
                orden = orden + " café,";
            }
            if (check3.IsChecked == true)
            {
                orden = orden + " menta";
            }

            labelOrden.Content = orden;

        }

        private void btotonVentana_Click(object sender, RoutedEventArgs e)
        {
            Ventana2 v2 = new Ventana2();
            v2.padre = this;
            v2.Show(); //muestra una ventana
            this.Hide(); //esconde una ventana
            //v2.Close(); //destruyes ventana

        }

        private void BotonCafe_Click(object sender, RoutedEventArgs e)
        {
            Ventana3 v3 = new Ventana3();
            v3.padre = this;
            v3.Show(); //muestra una ventana
            this.Hide(); //esconde una ventana
            //v3.Close(); //destruyes ventana
        }
    }
}
