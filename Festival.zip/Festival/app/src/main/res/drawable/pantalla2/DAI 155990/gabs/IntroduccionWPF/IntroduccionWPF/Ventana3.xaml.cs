﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IntroduccionWPF
{
    /// <summary>
    /// Lógica de interacción para Ventana3.xaml
    /// </summary>
    public partial class Ventana3 : Window
    {

        public Window padre { get; set; }

        public Ventana3()
        {
            InitializeComponent();
        }

        private void cerrar_v3(object sender, System.ComponentModel.CancelEventArgs e)
        {
            padre.Show();
        }

        private void Boton1_Click(object sender, RoutedEventArgs e)
        {

            String o = "Su orden es: ";

            if (Orden.IsChecked == true)
            {
                if (c1.IsChecked==true)
                {
                    o = o + "americano chico, ";           
                }
                if (m1.IsChecked == true)
                {
                    o = o + "americano mediano, ";
                }
                if (g1.IsChecked == true)
                {
                    o = o + "americano grande, ";
                }

                if (c2.IsChecked == true)
                {
                    o = o + "mocha chico, ";
                }
                if (m2.IsChecked == true)
                {
                    o = o + "mocha mediano, ";
                }
                if (g2.IsChecked == true)
                {
                    o = o + "mocha grande, ";
                }

                if (c3.IsChecked == true)
                {
                    o = o + "expresso chico ";
                }
                if (m3.IsChecked == true)
                {
                    o = o + "expresso mediano ";
                }
                if (g3.IsChecked == true)
                {
                    o = o + "expresso grande ";
                }

                orden.Content = o;
            }
            else
            {
                orden.Content = "Orden no lista";
            }


        }
    }
}
