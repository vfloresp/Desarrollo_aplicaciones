create table asistente(claveA int primary key,

nombre varchar(50) not null,

email varchar(50) not null unique,

edad int)

create table ponente(claveP int primary key,

nombre varchar(50) not null,

puesto varchar(50) not null)

create table conferencia(claveC int primary key,

nombre varchar(50) not null,

tema varchar(100) not null,

fecha datetime,

claveP int references ponente)

create table asistencia(claveA int references asistente,

claveC int references conferencia,

primary key (claveA,claveC))


insert into asistente values(1,'Juan', 'j@gmail.com', 20)
Select * from asistente
Select Count(claveA) from asistente where claveA = 3