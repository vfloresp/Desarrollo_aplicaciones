﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class pagina1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write("Binevenido " + Session["nomUsuario"].ToString());
        Response.Write("<br/>El identificador de esta sesion es: " + Session.SessionID);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //borra la sesion
        Session.Clear();
        //sale de la sesion
        Session.Abandon();

        Response.Redirect("index.aspx");
    }
}