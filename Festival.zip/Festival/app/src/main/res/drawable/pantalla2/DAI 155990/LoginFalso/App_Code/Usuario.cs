﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de Usuario
/// </summary>
public class Usuario
{
    public String correo { get; set; }
    public String password { get; set; }
    public String nombre { get; set; }

	public Usuario()
	{
		//
		// TODO: Agregar aquí la lógica del constructor
		//
        correo = "";
        password = "";
        nombre = "";
	}

    public Usuario(String c, String p, String n)
    {
        this.correo = c;
        this.password = p;
        this.nombre = n;
    }
}