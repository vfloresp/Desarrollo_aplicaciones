﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Odbc;

public partial class busqueda : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("usuario.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("index.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            String nombre = TextBox1.Text;
            String cLib = TextBox2.Text;
            String autor = TextBox3.Text;
            String editorial = TextBox4.Text;
           
            if (nombre == "" && cLib == "" && autor == "" && editorial == "")
            {
                Label1.Text = "Escriba algún parámetro";
            }
            else
            {
                int cLibro;

                if (TextBox2.Text == "")
                {
                    cLibro = 0;
                }
                else
                {
                     cLibro = Int32.Parse(TextBox2.Text);   
                }
                

                Label1.Text = "";
                String query = "select * from libro where ";
                String where = "1=1";

                if (nombre != "")
                {
                    where = where + " and nombre = ?";
                }
                if (cLibro != 0)
                {
                    where = where + " and cLibro = ?";
                }
                if (autor != "")
                {
                    where = where + " and autor = ?";
                }
                if (editorial != "")
                {
                    where = where + " and editorial = ?";
                }

                query = query + where;

                OdbcConnection con = new ConexionDB().con;
                con.Open();
                OdbcCommand comando = new OdbcCommand(query, con);

                if (nombre != "")
                {
                    comando.Parameters.Add("nombre", OdbcType.VarChar).Value = nombre;
                }
                if (cLibro != 0)
                {
                    comando.Parameters.Add("cLibro", OdbcType.Int).Value = cLibro;
                }
                if (autor != "")
                {
                    comando.Parameters.Add("autor", OdbcType.VarChar).Value = autor;
                }
                if (editorial != "")
                {
                    comando.Parameters.Add("editorial", OdbcType.VarChar).Value = editorial;
                }

                
                OdbcDataReader lector = comando.ExecuteReader();
                
                GridView1.DataSource = lector;
                GridView1.DataBind();
            }

        }
        catch (Exception ex)
        {

            Response.Write("Libro no existe" + ex.ToString());
        }
    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        try
        {
            if (TextBox5.Text == "")
            {
                Label2.Text = "Escriba la clave del libro deseado";
            }
            else
            {
                Label2.Text = "";

                OdbcConnection con = new ConexionDB().con;
                con.Open();

                int cLibro = Int32.Parse(TextBox5.Text);

                String query = "select renta.cTipoRen from libro, us_li_ren, renta where libro.cLibro = us_li_ren.cLibro and us_li_ren.cRenta = renta.cRenta and libro.cLibro = ?";
                //ANTES : 

                OdbcCommand comand = new OdbcCommand(query, con);
                comand.Parameters.Add("cLibro", OdbcType.Int).Value = cLibro;
                OdbcDataReader lector = comand.ExecuteReader();
                lector.Read();
                int tipo;
                if (lector.HasRows == false)
                {
                    tipo = 2;
                }
                else
                {
                    tipo = lector.GetInt32(0);
                }

                if (tipo != 1)
                {////

                    query = "select dias_renta from libro where cLibro = ?";
                    comand = new OdbcCommand(query, con);
                    comand.Parameters.Add("cLibro", OdbcType.Int).Value = cLibro;
                    lector = comand.ExecuteReader();
                    lector.Read();
                    int dias = lector.GetInt32(0);


                    if (dias != 0)
                    {
                        query = "insert into renta values(?,?,?,1)";
                        comand = new OdbcCommand(query, con);
                        Random rn = new Random();
                        int cRen;
                        int existe;
                        do
                        {
                            cRen = rn.Next(9000);
                            //checar si la llave primaria existe
                            String query2 = "select COUNT (cRenta) from renta where cRenta=" + cRen;
                            OdbcCommand comando2 = new OdbcCommand(query2, con);
                            existe = (Int32)comando2.ExecuteScalar();
                        } while (existe != 0);

                        comand.Parameters.Add("cRenta", OdbcType.Int).Value = cRen;
                        comand.Parameters.Add("fechaIni", OdbcType.Date).Value = DateTime.Now;
                        comand.Parameters.Add("fechaFin", OdbcType.Date).Value = DateTime.Now.AddDays(dias);
                        lector = comand.ExecuteReader();
                        lector.Read();
                        

                        int cUs = Int32.Parse(Session["Clave"].ToString());
                        //Response.Write(cUs);

                        query = "insert into us_li_ren values (?,?,?)";
                        comand = new OdbcCommand(query, con);
                        comand.Parameters.Add("cUs", OdbcType.Int).Value = cUs;
                        comand.Parameters.Add("cLibro", OdbcType.Int).Value = cLibro;
                        comand.Parameters.Add("cRenta", OdbcType.Int).Value = cRen;
                        lector = comand.ExecuteReader();
                        lector.Read();

                        Label2.Text = "Renta satisfactoria, favor de regresar el: " + DateTime.Now.AddDays(dias);
                    }
                    else
                    {
                        Label2.Text = "No se puede rentar este libro";
                    }

                }
                else
                {
                    Label2.Text = "No se puede rentar este libro, este libro ya está rentado";
                }
                

               
                

                
                //OdbcCommand comando = new OdbcCommand(query, con);


               
            }
        }
        catch (Exception ex)
        {

            Response.Write("No se puede rentar " + ex.ToString());
        }
    }
}