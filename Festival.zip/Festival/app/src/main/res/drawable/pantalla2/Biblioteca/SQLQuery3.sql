

select  libro.nombre, libro.cLibro from libro, us_li_ren, usuario, renta, tipoRenta where us_li_ren.cUs = usuario.cUs and us_li_ren.cRenta = renta.cRenta and libro.cLibro = us_li_ren.cLibro and renta.cTipoRen = tipoRenta.cTipoRen and renta.cTipoRen=1 and  usuario.cUs = 559033

select renta.cRenta from usuario, us_li_ren, renta, libro, tipoRenta where usuario.cUs = us_li_ren.cUs and tipoRenta.cTipoRen = renta.cTipoRen  and  us_li_ren.cLibro = libro.cLibro and us_li_ren.cRenta = renta.cRenta and tipoRenta.cTipoRen = 1 and usuario.cUs = 220011 and libro.cLibro = 948485


select renta.cRenta from usuario, us_li_ren, renta, libro, tipoRenta where usuario.cUs = us_li_ren.cUs and tipoRenta.cTipoRen = renta.cTipoRen  and  us_li_ren.cLibro = libro.cLibro and us_li_ren.cRenta = renta.cRenta and tipoRenta.cTipoRen = 1 and usuario.cUs = 559033 and libro.cLibro = 789552

update renta set cTipoRen = 1 where  cRenta = 48

select renta.cTipoRen from libro, us_li_ren, renta where libro.cLibro = us_li_ren.cLibro and us_li_ren.cRenta = renta.cRenta and libro.cLibro = 948485

select usuario.cUs, fechaIn, fechaFin, cLibro, tipoRenta.nombre from renta, us_li_ren, tipoRenta, usuario where usuario.cUs=110011 and usuario.cUs = us_li_ren.cUs and us_li_ren.cRenta = renta.cRenta and tipoRenta.cTipoRen = renta.cTipoRen and tipoRenta.cTipoRen = 1

union
(select usuario.cUs, fechaIn, fechaFin, cLibro, tipoRenta.nombre from renta, us_li_ren, tipoRenta, usuario where usuario.cUs=110011 and usuario.cUs = us_li_ren.cUs and us_li_ren.cRenta = renta.cRenta and tipoRenta.cTipoRen = renta.cTipoRen and tipoRenta.cTipoRen = 2)
union
(select usuario.cUs, fechaIn, fechaFin, cLibro, tipoRenta.nombre from renta, us_li_ren, tipoRenta, usuario where usuario.cUs=110011 and usuario.cUs = us_li_ren.cUs and us_li_ren.cRenta = renta.cRenta and tipoRenta.cTipoRen = renta.cTipoRen and tipoRenta.cTipoRen = 3)


select dias_renta from libro where cLibro = 948485

select*from renta
select*from libro

select tipoRenta.cTipoRen from libro, us_li_ren, renta, tipoRenta where libro.cLibro = us_li_ren.cLibro and us_li_ren.cRenta = renta.cRenta and renta.cTipoRen = tipoRenta.cTipoRen and libro.cLibro = 601654

