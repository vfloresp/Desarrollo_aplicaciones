﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Index : System.Web.UI.Page
{
    Usuario[] usuarios;
    String[] usu = { "jorge@hotmail.com", "paty@gmail.com", "luis@yaho.com", "dani@hotmail.com", "gerardo@gmail.com" };
    String[] passwords = { "jorgito", "patricia", "luisito", "daniela", "ger" };


    protected void Page_Load(object sender, EventArgs e)
    {
        usuarios = new Usuario[5];
        usuarios[0] = new Usuario("jorge@hotmail.com", "jorgito", "jorge");
        usuarios[1] = new Usuario("paty@gmail.com", "patricia", "patricia");
        usuarios[2] = new Usuario("luis@yaho.com", "luisito", "luisito");
        usuarios[3] = new Usuario("dani@hotmail.com", "daniela", "daniela");
        usuarios[4] = new Usuario("gerardo@gmail.com", "ger", "gerardo");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int i = 0;
        while(i<usuarios.Length && TextBox1.Text!=usuarios[i].correo)
        {
            i++;
        }
        if (i < usuarios.Length)
        {//si encontro el usuario en la lista de usuairos
            if (TextBox2.Text == usuarios[i].password)
            {
                //El usuario exite y sabe su password
                //Hacer una redireccion
                //Response.Write("Usuario y contraseña correcta");
                //Pasar a la pagina 1 desde el codigo
                Session.Add("nomUsuario", usuarios[i].nombre);
                Response.Redirect("pagina1.aspx");
            }
            else
            {
                //El usuario eciste, pero no sabe su password
                Response.Write("Contraseña incorrecta");
            }
        }
        else
        {
            Response.Write("El usuario no existe");
        }

    }
}