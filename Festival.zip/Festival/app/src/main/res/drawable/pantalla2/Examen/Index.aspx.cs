﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (RadioButtonList1.Items.Count == 0)
        {
            RadioButtonList1.Items.Add(new ListItem("1946","1"));
            RadioButtonList1.Items.Add(new ListItem("1956", "2"));
            RadioButtonList1.Items.Add(new ListItem("1939", "3"));
            RadioButtonList1.Items.Add(new ListItem("1942", "4"));
        }
        if (CheckBoxList1.Items.Count == 0)
        {
            CheckBoxList1.Items.Add(new ListItem("David Glimour", "1"));
            CheckBoxList1.Items.Add(new ListItem("Roger Waters", "2"));
            CheckBoxList1.Items.Add(new ListItem("Syd Barret", "3"));
            CheckBoxList1.Items.Add(new ListItem("Nick Maison", "4"));
        }
        if (DropDownList1.Items.Count == 0)
        {
            DropDownList1.Items.Add(new ListItem("Wish you Were Here", "1"));
            DropDownList1.Items.Add(new ListItem("Atom Heart Mother", "2"));
            DropDownList1.Items.Add(new ListItem("The final cut", "3"));
            DropDownList1.Items.Add(new ListItem("Meddle", "4"));
            DropDownList1.Items.Add(new ListItem("The Endless River", "5"));
        }
        if (RadioButtonList2.Items.Count == 0)
        {
            RadioButtonList2.Items.Add(new ListItem("Verdadero", "1"));
            RadioButtonList2.Items.Add(new ListItem("Falso", "2"));
        }
        if (CheckBoxList2.Items.Count == 0)
        {
            CheckBoxList2.Items.Add(new ListItem("Comfortably Numb", "1"));
            CheckBoxList2.Items.Add(new ListItem("A Saucerful of Secrets", "2"));
            CheckBoxList2.Items.Add(new ListItem("The Thin Ice", "3"));
            CheckBoxList2.Items.Add(new ListItem("Coming Back to Life", "4"));
        }
        if (RadioButtonList3.Items.Count == 0)
        {
            RadioButtonList3.Items.Add(new ListItem("Verdadero", "1"));
            RadioButtonList3.Items.Add(new ListItem("Falso", "2"));
        }
        if (CheckBoxList3.Items.Count == 0)
        {
            CheckBoxList3.Items.Add(new ListItem("Floyd Davis", "1"));
            CheckBoxList3.Items.Add(new ListItem("Pink Anderson", "2"));
            CheckBoxList3.Items.Add(new ListItem("Floyd Council", "3"));
            CheckBoxList3.Items.Add(new ListItem("Pink Collins", "4"));
        }

    }


    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedItem.Text == "1946")
        {
            Label1.Text = "correcto";
        }
        else
        {
            Label1.Text="incorrecto";
        }
    }
    protected void CheckBoxList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {

        if (CheckBoxList1.Items[1].Selected == true && CheckBoxList1.Items[2].Selected == true 
            && CheckBoxList1.Items[3].Selected == true && CheckBoxList1.Items[0].Selected == false)
        {
            Label2.Text = "correcto";
        }
        else
        {
            Label2.Text = "incorrecto";
        }
        
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "the dark side of the moon")
        {
            Label3.Text = "correcto";
        }
        else
        {
            Label3.Text = "incorrecto";
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        ListBox1.Items.Add(DropDownList1.SelectedItem.Text);
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        if (ListBox1.SelectedItem.Text == "Meddle" || ListBox1.SelectedItem.Text == "Atom Heart Mother" || ListBox1.SelectedItem.Text == "Wish you Were Here")
        {
            Label4.Text = "correcto";
        }
        else
        {
            Label4.Text = "incorrecto";
        }
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        if (RadioButtonList2.Items[0].Selected == true)
        {
            Label5.Text = "correcto";
        }
        else
        {
            Label5.Text = "incorecto";
        }
    }

    protected void RadioButtonList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void CheckBoxList2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        if (CheckBoxList2.Items[0].Selected == true && CheckBoxList2.Items[2].Selected == true
            && CheckBoxList2.Items[1].Selected == false && CheckBoxList2.Items[3].Selected == false)
        {
            Label6.Text = "correcto";
        }
        else
        {
            Label6.Text = "incorrecto";
        }
    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        if (TextBox2.Text == "15")
        {
            Label7.Text = "correcto";
        }
        else
        {
            Label7.Text = "incorrecto";
        }
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        if (TextBox3.Text == "the piper at the gates of dawn")
        {
            Label8.Text = "correcto";
        }
        else
        {
            Label8.Text = "incorrecto";
        }
    }
    protected void RadioButtonList3_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        if (RadioButtonList3.Items[1].Selected == true)
        {
            Label9.Text = "correcto";
        }
        else
        {
            Label9.Text = "incorecto";
        }
    }
    protected void Button10_Click(object sender, EventArgs e)
    {
        if (CheckBoxList3.Items[1].Selected == true && CheckBoxList3.Items[2].Selected == true
            && CheckBoxList3.Items[3].Selected == false && CheckBoxList3.Items[0].Selected == false)
        {
            Label10.Text = "correcto";
        }
        else
        {
            Label10.Text = "incorrecto";
        }
    }
}