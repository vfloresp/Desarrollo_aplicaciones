insert into rol values(01, 'administrador')
insert into rol values(02, 'usuario')

insert into usuario values (110011, 'Ana Luisa', 'ana@gmail.com','patatas',01)
insert into usuario values (110012, 'Fernando', 'feri@gmail.com','osopanda',01)
insert into usuario values (220011, 'Carmen', 'car@hotmail.com','123456',02)
insert into usuario values (220123, 'Octavio', '8c@gmail.com','sapo',02)
insert into usuario values (227879, 'Diego', 'Diego@gmail.com','dieguito',01)
insert into usuario values (894511, 'Paula', 'Pau@gmail.com','24ocho',01)
insert into usuario values (478883, 'Renata', 'reni@gmail.com','crepas',02)
insert into usuario values (789623, 'Lalo', 'edi@gmail.com','muffin',02)

insert into area values (9123,'Restringido')
insert into area values (9045,'Uso libre')
insert into area values (9289,'Solo lectura')


insert into libro values (948485,'Alicia en el pa�s de las maravillas', 'Lewis Carroll', 'Patito',10,9045)
insert into libro values (878999,'Estudios #17', 'ITAM', 'Docs ITAM',0,9289)
insert into libro values (789985,'La Iliada', 'Homero', 'Real',5,9123)
insert into libro values (789552,'Conejos salvajes', 'Juan P�rez', 'Pez dorado',20,9045)
insert into libro values (963201,'Reforma 12101995', 'Reforma', 'Reforma',0,9289)
insert into libro values (878455,'Conejos salvajes 2', 'Gaby', 'Reforma',10,9045)
insert into libro values (369875,'Patatas', 'Docs Itam', 'Reforma',7,9045)
insert into libro values (789965,'La m�sica', 'Docs Itam', 'ITAM',10,9045)
insert into libro values (369845,'Lentes nuevos', 'Juan P�rez', 'Pecesitos',15,9045)
insert into libro values (369802,'Tomates verdes', 'Jorge Gonz�lez', 'PlantasZ',13,9045)

insert into tipoRenta values(2, 'Pasada')
insert into tipoRenta values(1, 'Actual')

insert into renta values(00789,'2015-10-10','2015-12-10',2) 
insert into renta values(00895,'2016-02-11','2016-03-14',2)
insert into renta values(00889,'2016-10-10','2016-12-11',1)
insert into renta values(00123,'2016-01-16','2016-02-11',2)
insert into renta values(00456,'2016-02-15','2016-03-04',2)
insert into renta values(00025,'2016-03-14','2016-03-21',2)
insert into renta values(00852,'2016-10-13','2016-10-30',1)
insert into renta values(00963,'2016-09-12','2016-11-11',1)
insert into renta values(00159,'2016-10-11','2016-11-30',1)
insert into renta values(00369,'2016-10-01','2016-10-20',1)
insert into renta values(00577,'2016-10-02','2016-11-01',1)


insert into us_li_ren values (220123,878999,00789) 
insert into us_li_ren values (220123,789552,00895)
insert into us_li_ren values (220011,948485,00889)
insert into us_li_ren values (220011,789552, 00123)
insert into us_li_ren values (478883,369802, 00456)
insert into us_li_ren values (789623,369845, 00025)
insert into us_li_ren values (220011,789552, 00852)
insert into us_li_ren values (478883,963201, 00963)
insert into us_li_ren values (220123,878455, 00159)
insert into us_li_ren values (478883,369802, 00369)
insert into us_li_ren values (789623,369845, 00577)

select  *from rol
select  *from usuario
select  *from area
select * from libro
select * from tipoRenta 
select * from renta 
select * from us_li_ren

update libro set cArea = 9045 , dias_renta = 15 where libro.nombre = 'Popol vu'

--delete from us_li_ren
--delete from renta
--delete from libro


