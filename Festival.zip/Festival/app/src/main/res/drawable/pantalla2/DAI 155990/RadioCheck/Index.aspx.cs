﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (RadioButtonList1.Items.Count == 0)
        {
            RadioButtonList1.Items.Add(new ListItem("1er semestre ","1 "));
             RadioButtonList1.Items.Add(new ListItem("2do semestre ","2 "));
             RadioButtonList1.Items.Add(new ListItem("3er semestre ","3 "));
             RadioButtonList1.Items.Add(new ListItem("4to semestre ","4 "));
        }

        if (CheckBoxList1.Items.Count == 0)
        {
            CheckBoxList1.Items.Add(new ListItem("Enchiladas", "20"));
            CheckBoxList1.Items.Add(new ListItem("Enfrijoladas", "30"));
            CheckBoxList1.Items.Add(new ListItem("Molletes", "40"));
            CheckBoxList1.Items.Add(new ListItem("Gorditas", "50"));
        }

    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label1.Text = "felcicidades, vas en " + RadioButtonList1.SelectedItem.Text;
    }

    protected void CheckBoxList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label2.Text = "";
        for (int i = 0; i < CheckBoxList1.Items.Count; i++)
        {
            if (CheckBoxList1.Items[i].Selected == true)
            {
                Label2.Text = Label2.Text + CheckBoxList1.Items[i].Text + "<br />";
            }
        }
    }
}